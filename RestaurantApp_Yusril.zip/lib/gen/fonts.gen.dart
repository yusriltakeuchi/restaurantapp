/// GENERATED CODE - DO NOT MODIFY BY HAND
/// *****************************************************
///  FlutterGen
/// *****************************************************

// ignore_for_file: directives_ordering

class FontFamily {
  FontFamily._();

  /// Font family: NunitoSans
  static const String nunitoSans = 'NunitoSans';
}
